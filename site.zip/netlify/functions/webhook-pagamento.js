// Recebe o aviso de pagamento da InfinitePay e registra no painel (Netlify Forms).
// Regra de ouro: so grava CONFIRMADO com prova positiva de pagamento.
// Na duvida, grava PRECISA CONFERIR - nunca o contrario.

const SEGREDO = "sa_9f3c1e7b";   // tem que bater com o ?k= da webhook_url do site

exports.handler = async (event) => {
  if (event.httpMethod === "GET") {
    return { statusCode: 200, body: JSON.stringify({ ok: true, msg: "webhook ativo" }) };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  // so aceita chamada que traga o segredo da URL
  const chave = (event.queryStringParameters && event.queryStringParameters.k) || "";
  if (chave !== SEGREDO) {
    return { statusCode: 403, body: JSON.stringify({ error: "forbidden" }) };
  }

  let d = {};
  try { d = JSON.parse(event.body || "{}"); } catch (e) { d = {}; }
  const dd = d.data && typeof d.data === "object" ? d.data : {};
  const campo = (nome) => (d[nome] !== undefined ? d[nome] : dd[nome]);

  const pedido =
    campo("order_nsu") || campo("external_order_nsu") || d.orderNsu || "(sem numero)";

  const centavos = campo("amount") || campo("paid_amount") || campo("value") || null;
  const valor = centavos
    ? "R$ " + (Number(centavos) / 100).toFixed(2).replace(".", ",")
    : "(ver no app)";

  const metodo = campo("payment_method") || campo("paymentMethod") || campo("method") || "-";

  // prova POSITIVA de pagamento: precisa de sinal explicito de sucesso E de valor
  const statusTxt = String(campo("status") || "").toLowerCase();
  const sucessoExplicito =
    campo("captured") === true ||
    campo("paid") === true ||
    campo("success") === true ||
    ["paid", "approved", "captured", "succeeded", "confirmed"].includes(statusTxt);

  const falhaExplicita =
    campo("captured") === false ||
    campo("paid") === false ||
    ["failed", "refused", "declined", "canceled", "cancelled", "refunded", "chargeback"].includes(statusTxt);

  let status;
  if (falhaExplicita) status = "FALHOU / NAO CAPTURADO";
  else if (sucessoExplicito && centavos) status = "PAGAMENTO CONFIRMADO";
  else status = "PRECISA CONFERIR NO APP";

  const params = new URLSearchParams({
    "form-name": "pagamentos",
    pedido: String(pedido),
    status: status,
    valor: String(valor),
    metodo: String(metodo),
    recebido: new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" }),
    detalhes: JSON.stringify(d).slice(0, 1800)
  });

  try {
    await fetch("https://solidarquives.netlify.app/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString()
    });
  } catch (e) {
    // mesmo se o registro falhar, respondemos 200 pra InfinitePay nao reenviar em loop
  }

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ received: true })
  };
};
